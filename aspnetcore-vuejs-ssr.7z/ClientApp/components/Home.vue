<template>
  <h1>Home Component:</h1>
</template>
